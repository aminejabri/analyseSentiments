import numpy
import matplotlib
import pandas


class Grapher:

    def main(self):
        pass
