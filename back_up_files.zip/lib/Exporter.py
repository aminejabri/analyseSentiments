class Exporter:

    def exportToCSV(self):
        pass
